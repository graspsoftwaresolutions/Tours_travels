(function($){

	var options = {
		valueNames: [ 'item-title' ]
	};

	var filesList = new List('files', options);

})(jQuery);