<script src="{{ asset('public/assets/dist/js/jquery.min.js') }}"></script>
<script src="{{ asset('public/assets/dist/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('public/assets/dist/js/bower.min.js') }}"></script>

<!-- Sortable script -->
<script src="{{ asset('public/assets/dist/js/plugins/sortable/sortable.min.js') }}"></script>

<!-- peity charts -->
<script src="{{ asset('public/assets/dist/js/plugins/peity-charts/jquery.peity.min.js') }}"></script>

<!-- worldmap script -->
<script src="{{ asset('public/assets/dist/js/plugins/jvectormap/jquery-jvectormap.min.js') }}"></script>
<script src="{{ asset('public/assets/dist/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js') }}"></script>

<!-- Cart script d3 script must be loaded before c3 -->
<script src="{{ asset('public/assets/dist/js/plugins/d3/d3.min.js') }}"></script>
<script src="{{ asset('public/assets/dist/js/plugins/c3/c3.min.js') }}"></script>

<!-- app -->
<script src="{{ asset('public/assets/dist/js/app.js') }}"></script>

<script src="{{ asset('public/assets/demo/demo-dashboard-sales.js') }}"></script>