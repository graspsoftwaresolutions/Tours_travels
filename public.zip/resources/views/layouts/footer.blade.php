<footer class="page-footer toolbar">
	
	<p class="pull-right pr20">© {{ date('Y') }} Tours & Travels</p>
</footer>
