<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
    <body class="theme-mda light-skin ev-page" >
    	<div class="preloader-bg"></div>
		<div class="preloader-overlay"></div>
		<div class="main-wrapper side-menu">
			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="menu-toggler-hide pos-left"><i class="toggler-hide-icon"></i></div>
			<?php $__env->startSection('main-content'); ?>
				<?php echo $__env->yieldSection(); ?>
			 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<?php echo $__env->make('layouts.foot-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH E:\xampp\htdocs\Tours_travels\resources\views/layouts/admin.blade.php ENDPATH**/ ?>