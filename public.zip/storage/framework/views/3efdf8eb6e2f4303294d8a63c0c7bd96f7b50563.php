<footer class="page-footer toolbar">
	
	<p class="pull-right pr20">© <?php echo e(date('Y')); ?> Tours & Travels</p>
</footer>
<?php /**PATH E:\xampp\htdocs\Tours_travels\resources\views/layouts/footer.blade.php ENDPATH**/ ?>