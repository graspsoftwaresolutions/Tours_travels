<script src="<?php echo e(asset('public/assets/dist/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/dist/js/bower.min.js')); ?>"></script>
<script type="text/javascript">
	var base_url = '<?php echo e(URL::to("/")); ?>';
	var image_url = '<?php echo e(asset("storage/app/")); ?>';
	var no_image_url = '<?php echo e(asset("public/assets/images/no_image.jpg")); ?>';
</script>
<?php $__env->startSection('footerSection'); ?>
<?php echo $__env->yieldSection(); ?>
<!-- app -->
<script src="<?php echo e(asset('public/assets/dist/js/app.js')); ?>"></script>
<?php $__env->startSection('footerSecondSection'); ?>
<?php echo $__env->yieldSection(); ?>
<script type="text/javascript">
	$(".alert").fadeTo(4000, 1000).slideUp(2500, function () {
	    $(".alert").slideUp(2500);
	});
</script><?php /**PATH E:\xampp\htdocs\Tours_travels\resources\views/layouts/foot-script.blade.php ENDPATH**/ ?>